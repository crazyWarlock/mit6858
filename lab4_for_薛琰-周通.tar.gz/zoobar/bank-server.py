#!/usr/bin/python
#
# Insert bank server code here.
#

import rpclib
import sys
from debug import *
import bank

class BankRpcServer(rpclib.RpcServer):
    def rpc_transfer(self, s, r, z, t):
        return bank.transfer(s,r,z, t) 
    
    def rpc_balance(self,u):
        return bank.balance(u)
    
    def rpc_get_log(self,u):
        return bank.get_log(u)
    
    def rpc_register(self, u):
        return bank.register(u)
    def rpc_profile_transfer(self, s, r, z):
        return bank.profile_transfer(s,r,z)

(_, dummy_zookld_fd, sockpath)=sys.argv
s = BankRpcServer()
s.run_sockpath_fork(sockpath)       


