from debug import *
from zoodb import *
import rpclib

@catch_err
def login(username, password):
    ## Fill in code here.
    with rpclib.client_connect('/authsvc/sock') as c:
        ret = c.call('login', u=username, p=password)
        return ret
    
@catch_err
def register(username, password):
    ## Fill in code here.

    with rpclib.client_connect('/authsvc/sock') as c:
        ret = c.call('register', u=username, p=password)
        return ret
    
@catch_err
def check_token(username, token):
    ## Fill in code here.
    with rpclib.client_connect('/authsvc/sock') as c:
        ret = c.call('check_token',u=username, t=token)
        return ret
    

