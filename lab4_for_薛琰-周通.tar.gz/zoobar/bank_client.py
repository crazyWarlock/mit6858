from debug import *
from zoodb import *
import rpclib

@catch_err
def transfer(sender,recipient, zoobars, token):
    with rpclib.client_connect('/banksvc/sock') as c:
        ret = c.call('transfer',s=sender, r=recipient, z=zoobars, t=token)
        return ret


@catch_err
def balance(username):
    with rpclib.client_connect('/banksvc/sock') as c:
        ret = c.call('balance', u= username)
        return ret


@catch_err
def get_log(username):
    with rpclib.client_connect('/banksvc/sock') as c:
        ret = c.call('get_log', u=username)
        return ret


@catch_err
def register(username):
    with rpclib.client_connect('/banksvc/sock') as c:
        ret = c.call('register',u=username)
        return ret

@catch_err
def profile_transfer(sender,recipient,zoobars):
    with rpclib.client_connect('/banksvc/sock') as c:
        ret = c.call('profile_transfer',s=sender,r=recipient, z=zoobars)
        return ret

