from zoodb import *
from debug import *
import auth_client
import time

def transfer(sender, recipient, zoobars, token):
    bankdb = bank_setup()
    transferdb = transfer_setup()
    senderp = bankdb.query(Bank).get(sender)
    recipientp = bankdb.query(Bank).get(recipient)
    sender_balance = senderp.zoobars - zoobars
    recipient_balance = recipientp.zoobars + zoobars

    if zoobars < 0 or sender_balance < 0 or recipient_balance < 0:
        raise ValueError()
    if(not auth_client.check_token(sender, token)): 
        raise ValueError()
    senderp.zoobars = sender_balance
    recipientp.zoobars = recipient_balance
    bankdb.commit()
    transfer = Transfer()
    transfer.sender = sender
    transfer.recipient = recipient
    transfer.amount = zoobars
    transfer.time = time.asctime()

    transferdb.add(transfer)
    transferdb.commit()

def balance(username):
    db = bank_setup()
    bank = db.query(Bank).get(username)
    return bank.zoobars

def get_log(username):
    db = transfer_setup()
    sql = db.query(Transfer).filter(or_(Transfer.sender==username, Transfer.recipient==username))
    #transfers = db.execute(sql)
    #print transfers.__dict__
    return sql
def register(username):
    db = bank_setup()
    newbank = Bank()
    newbank.username = username
    db.add(newbank)
    db.commit()

def profile_transfer(sender, recipient, zoobars):
    bankdb = bank_setup()
    transferdb = transfer_setup()
    senderp = bankdb.query(Bank).get(sender)
    recipientp = bankdb.query(Bank).get(recipient)
    sender_balance = senderp.zoobars - zoobars
    recipient_balance = recipientp.zoobars + zoobars

    if zoobars < 0 or sender_balance < 0 or recipient_balance < 0:
        raise ValueError()
    senderp.zoobars = sender_balance
    recipientp.zoobars = recipient_balance
    bankdb.commit()
    transfer = Transfer()
    transfer.sender = sender
    transfer.recipient = recipient
    transfer.amount = zoobars
    transfer.time = time.asctime()

    transferdb.add(transfer)
    transferdb.commit()

